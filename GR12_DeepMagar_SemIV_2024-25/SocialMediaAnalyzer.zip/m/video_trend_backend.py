from flask import Flask, render_template, jsonify, request, Blueprint
from googleapiclient.discovery import build
import pandas as pd
import datetime
from vaderSentiment.vaderSentiment import SentimentIntensityAnalyzer
import time

video_trend_bp = Blueprint('video_trend',__name__)
analyzer = SentimentIntensityAnalyzer()

# API Configuration
API_KEY = "AIzaSyBwi9VeYhhO-jiyjprqiOmNdIL4IYLSGVc"  # Replace with your actual YouTube Data API key
youtube = build('youtube', 'v3', developerKey=API_KEY)

# Caching Variables
cached_data = {}
CACHE_TTL = 3600  # 1 hour cache

def fetch_video_categories():
    try:
        response = youtube.videoCategories().list(
            part="snippet",
            regionCode="IN"
        ).execute()
        return {item["id"]: item["snippet"]["title"] for item in response["items"]}
    except Exception as e:
        print(f"Category fetch error: {e}")
        return {}

def fetch_trending_videos(category_id):
    try:
        response = youtube.videos().list(
            part="snippet,statistics",
            chart="mostPopular",
            regionCode="IN",
            maxResults=50,
            videoCategoryId=category_id
        ).execute()
        
        videos = []
        thirty_days_ago = datetime.datetime.utcnow() - datetime.timedelta(days=30)
        
        for item in response.get("items", []):
            published_str = item["snippet"].get("publishedAt")
            if published_str:
                published_date = datetime.datetime.strptime(published_str, "%Y-%m-%dT%H:%M:%SZ")
                if published_date < thirty_days_ago:
                    continue
            
            title = item["snippet"]["title"]
            views = int(item["statistics"].get("viewCount", 0))
            likes = int(item["statistics"].get("likeCount", 0))
            comments = int(item["statistics"].get("commentCount", 0))
            engagement_rate = ((likes + comments) / views) * 100 if views > 0 else 0
            
            videos.append({
                "title": title,
                "views": views,
                "likes": likes,
                "comments": comments,
                "engagement_rate": round(engagement_rate, 2)
            })
        
        return videos
    except Exception as e:
        print(f"Video fetch error: {e}")
        return []

@video_trend_bp.route('/video/trend-data')
def video_trend_data():
    category_id = request.args.get('category_id')
    if not category_id:
        return jsonify({"status": "error", "message": "Category ID is required"}), 400

    current_time = time.time()
    cache_entry = cached_data.get(category_id)
    
    if cache_entry and (current_time - cache_entry['last_update']) < CACHE_TTL:
        return jsonify({"status": "success", "data": cache_entry['data'], "source": "cache"})
    
    videos = fetch_trending_videos(category_id)
    if not videos:
        return jsonify({"status": "error", "message": "No video data found"}), 404
    
    df = pd.DataFrame(videos)
    analysis = {
        "top_video": df.loc[df['views'].idxmax()]['title'],
        "max_views": int(df['views'].max()),
        "views_distribution": {
            "q1": int(df['views'].quantile(0.25)),
            "median": int(df['views'].median()),
            "q3": int(df['views'].quantile(0.75))
        },
        "avg_engagement": round(df['engagement_rate'].mean(), 2),
        "total_comments": int(df['comments'].sum())
    }
    
    result_data = {
        "category": fetch_video_categories().get(category_id, "Unknown"),
        "videos": videos,
        "analysis": analysis
    }
    
    cached_data[category_id] = {
        'data': result_data,
        'last_update': current_time
    }
    
    return jsonify({"status": "success", "data": result_data, "source": "new"})
