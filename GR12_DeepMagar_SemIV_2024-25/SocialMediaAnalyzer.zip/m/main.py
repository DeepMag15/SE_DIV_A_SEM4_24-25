# main.py
from flask import Flask, send_from_directory
from database_backend import auth_bp
from trend_backend import trend_bp
from video_trend_backend import video_trend_bp

app = Flask(__name__, static_folder='static')

# Register blueprints so that endpoints are unified under one application
app.register_blueprint(auth_bp) 
app.register_blueprint(trend_bp)
app.register_blueprint(video_trend_bp)

@app.route('/')
def index():
    # Serve the frontend HTML file (place your index.html inside a folder called 'static')
    return send_from_directory('static', 'index.html')

if __name__ == '__main__':
    app.run(debug=True)
