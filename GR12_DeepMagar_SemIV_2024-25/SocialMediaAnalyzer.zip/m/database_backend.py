# auth_backend.py
from flask import Blueprint, request, jsonify
import mysql.connector
from mysql.connector import Error

auth_bp = Blueprint('auth', __name__)

def create_connection():
    """
    Establish a connection to the MySQL database.
    Replace with your actual database credentials.
    """
    try:
        connection = mysql.connector.connect(
            host='localhost',
            database='trendanalysis',  # Your database name
            user='users',              # Your MySQL username
            password='123456'          # Your MySQL password
        )
        if connection.is_connected():
            return connection
    except Error as e:
        print("Error connecting to MySQL:", e)
        return None

def check_user(email, password):
    """
    Check if a user exists in the 'users' table with the provided email and password.
    """
    connection = create_connection()
    if connection is None:
        return None
    try:
        cursor = connection.cursor(dictionary=True)
        query = "SELECT * FROM users WHERE email = %s AND password = %s"
        cursor.execute(query, (email, password))
        return cursor.fetchone()
    except Error as e:
        print("Error checking user:", e)
        return None
    finally:
        if connection.is_connected():
            cursor.close()
            connection.close()

def create_user(username, email, password):
    """
    Create a new user in the 'users' table.
    """
    connection = create_connection()
    if connection is None:
        return False
    try:
        cursor = connection.cursor()
        insert_query = "INSERT INTO users (username, email, password) VALUES (%s, %s, %s)"
        cursor.execute(insert_query, (username, email, password))
        connection.commit()
        return True
    except Error as e:
        print("Error creating user:", e)
        return False
    finally:
        if connection.is_connected():
            cursor.close()
            connection.close()

@auth_bp.route('/login', methods=['POST'])
def login():
    """
    Expects JSON payload with 'email' and 'password'.
    """
    data = request.get_json()
    email = data.get('email')
    password = data.get('password')
    user = check_user(email, password)
    if user:
        return jsonify({'status': 'success', 'message': 'Login successful', 'user': user})
    else:
        return jsonify({'status': 'fail', 'message': 'Invalid credentials'})

@auth_bp.route('/register', methods=['POST'])
def register():
    """
    Expects JSON payload with 'username', 'email', and 'password'.
    """
    data = request.get_json()
    username = data.get('username')
    email = data.get('email')
    password = data.get('password')
    if create_user(username, email, password):
        return jsonify({'status': 'success', 'message': 'Registration successful'})
    else:
        return jsonify({'status': 'fail', 'message': 'Registration failed'})
