from flask import Flask, render_template, jsonify, Blueprint
from googleapiclient.discovery import build
import pandas as pd
import time
import datetime
from vaderSentiment.vaderSentiment import SentimentIntensityAnalyzer

trend_bp = Blueprint('trend',__name__)
analyzer = SentimentIntensityAnalyzer()

    # API Configuration
API_KEY = "AIzaSyCqpo2DfFk4vP68L54pGXAcQ_71Ss24UAY"
youtube = build('youtube', 'v3', developerKey=API_KEY)

# Caching Variables
cached_data = None
last_update = 0
CACHE_TTL = 3600  # 1 hour cache

def fetch_video_categories():
    try:
        response = youtube.videoCategories().list(
            part="snippet",
            regionCode="IN"
        ).execute()
        return {item["id"]: item["snippet"]["title"] for item in response["items"]}
    except Exception as e:
        print(f"Category fetch error: {e}")
        return {}

def fetch_trending_videos(category_id):
    try:
        response = youtube.videos().list(
        part="snippet,statistics",
            chart="mostPopular",
            regionCode="IN",
            maxResults=50,
            videoCategoryId=category_id
        ).execute()
            
        videos = []
        thirty_days_ago = datetime.datetime.utcnow() - datetime.timedelta(days=30)
            
        for item in response.get("items", []):
            published_str = item["snippet"].get("publishedAt")
            if published_str:
                published_date = datetime.datetime.strptime(published_str, "%Y-%m-%dT%H:%M:%SZ")
                if published_date < thirty_days_ago:
                    continue
                
            title = item["snippet"]["title"]
            views = int(item["statistics"].get("viewCount", 0))
            sentiment = analyzer.polarity_scores(title)['compound']
            
            videos.append({
                "category_id": category_id,
                "views": views,
                "sentiment": sentiment
            })
            
        return videos
    except Exception as e:
            print(f"Video fetch error: {e}")
            return []



    @trend_bp.route('/market-trend-data', methods=['GET'])
    def market_trend_data():
        global cached_data, last_update
        current_time = time.time()
        
        if cached_data and (current_time - last_update) < CACHE_TTL:
            return jsonify({"status": "success", "data": cached_data, "source": "cache"})
        
        categories = fetch_video_categories()
        if not categories:
            return jsonify({"status": "error", "message": "Failed to fetch categories"})
        
        all_data = []
        for category_id in categories:
            videos = fetch_trending_videos(category_id)
            all_data.extend(videos)
        
        if not all_data:
            return jsonify({"status": "error", "message": "No video data found"})
        
        df = pd.DataFrame(all_data)
        agg_data = df.groupby('category_id').agg({
            'views': 'sum',
            'sentiment': 'mean'
        }).sort_values('views', ascending=False).head(10)
        
        category_names = [categories.get(idx, "Unknown") for idx in agg_data.index]
        
        result_data = {
            "categories": category_names,
            "views": agg_data['views'].values.tolist(),
            "sentiment": agg_data['sentiment'].values.tolist(),
            "updated": datetime.datetime.now().isoformat()
            
        }
        
        cached_data = result_data
        last_update = current_time
        
        return jsonify({"status": "success", "data": result_data, "source": "new"})
